#<FatMaus>

# ============================================================      
#                                                                     
# Student Name (as it appears on cuLearn): Weihang Chen               
# Student ID (9 digits in angle brackets): <101084865>               
# Course Code (for this current semester): COMP 1501 A                  
#                                                                    
# ============================================================  


from library_for_glad_ai_tors import *

import math
	




#----------Register variables----------#
# 'A' (state)            | char |'A' - move to corner| 'B' - ambush model | 'C' - hunter model
# 'B' (timer)            | int, recording the time passed
# 'C' (enemy X coord)    | float, recording the X-coordinate of the nearest enemy last appearance
# 'D' (enemy Y coord)    | float, recording the X-coordinate of the nearest enemy last appearance
# 'E' (taken damage)     | float,recording the damage has been taken
# 'F' (time of taken dam)| int,recording the last time had been damaged
# 'G' (hunt direction)   | int,recording the hunt direction | False = None | 10 - Ready to hunt | 1 - left | -1 - right 
#________________________|__________________________________| 2 - top | -2 - down | 3 - top-left | -3 - down-right 
#________________________|__________________________________| 4 - top-right | -4 - down-left
# 'H' (gun locked)       | bool or float, Fasle - gun has not locked | folat - gun has locked at this angle
# 'I' (timer for H&R)    | int,recording the time in the process of Hit and Run
def start(arg):
	return ("chioce", {'A': 'A','B':0,'C':100000,'D':100000,'E':0, 'F': 0, 'G':False,'I':0,'SHIELD': False})

def chioce(arg):
	re_diction = {}
	(x, y) = get_position(arg)
	(dx, dy) = get_velocity(arg)
	n_border = get_n_border(arg)
	s_border = get_s_border(arg)
	w_border = get_w_border(arg)
	e_border = get_e_border(arg)
	we_angle = get_weapon_angle(arg)
	we_power = get_weapon_power(arg)
	taken_damage = get_damage_level(arg)
	state_charge = is_charge_active(arg)
	state_shield = is_shield_active(arg)
	nearest_enemy_last_X = get_saved_data(arg, 'C')
	nearest_enemy_last_Y = get_saved_data(arg, 'D')
	if nearest_enemy_last_X == 100000 or nearest_enemy_last_Y == 100000:
		nearest_enemy_last_angle = None
		nearest_enemy_last_distance = None
	else:
		relative_x = nearest_enemy_last_X - x 
		relative_y = nearest_enemy_last_Y - y 
		if relative_x > 0:
			if relative_y > 0:
				nearest_enemy_last_angle = math.degrees(math.atan(relative_y/relative_x))
			elif relative_y < 0:
				nearest_enemy_last_angle = math.degrees(math.atan(relative_y/relative_x)) + 360
			elif relative_y == 0:
				nearest_enemy_last_angle = 0
		elif relative_x < 0:
			if relative_y > 0:
				nearest_enemy_last_angle = (math.degrees(math.atan(relative_y/relative_x)) + 180)
			elif relative_y < 0:
				nearest_enemy_last_angle = math.degrees(math.atan(relative_y/relative_x)) + 180
			elif relative_y == 0:
				nearest_enemy_last_angle = 180
		elif relative_x == 0:
			if relative_y > 0:
				nearest_enemy_last_angle = 90
			elif relative_y < 0:
				nearest_enemy_last_angle = 270
			elif relative_y == 0:
				nearest_enemy_last_angle = 'error' 
		nearest_enemy_last_distance = ((x - nearest_enemy_last_X)**2 + (y - nearest_enemy_last_Y)**2)**0.5


	had_taken_damage = get_saved_data(arg, 'E')
	last_time_been_attacked = get_saved_data(arg, 'F')
	timer = get_saved_data(arg, 'B')
	state = get_saved_data(arg, 'A')
	hunt_dir = get_saved_data(arg, 'G')
	H_R_timer = get_saved_data(arg, 'I')
	dis_to_left = x - w_border
	dis_to_right = e_border - x
	dis_to_top = y - n_border
	dis_to_down = s_border - y	
	



	# Timer
	timer += 1
	re_diction['B'] = timer


	# Searching for the nearest enemy and anticipates the direction of the fire
	nearest_dis = 100000
	nearest_ang = None
	H_R_delay = 50
	Hit_delay = 0
	Run_delay = 35
	for i in range(360):
		(target, distance) = get_radar_data(arg, i)
		if target == "opponent":
			if distance < nearest_dis-1:
				nearest_dis = distance
				nearest_ang = i
				new_enemy_x = math.cos(radians(nearest_ang))*nearest_dis + x
				new_enemy_y = math.sin(radians(nearest_ang))*nearest_dis + y
				Hit_delay = int(nearest_dis/40)-5
				if Hit_delay < 0:
					Hit_delay = 0
				if nearest_dis > 600:
					Run_delay = int(nearest_dis/80) + 40
	if nearest_ang == None:
		
		if nearest_enemy_last_angle != None:
			aim_line_angle = nearest_enemy_last_angle



		# Adjust weapon angles before spotting enemies
		elif nearest_enemy_last_angle == None:

			if dis_to_left > dis_to_right:
				if dis_to_top > dis_to_down:
					aim_line_angle = 135
				elif dis_to_down > dis_to_top:
					aim_line_angle = 225
				elif dis_to_down == dis_to_top:
					aim_line_angle = 180
			elif dis_to_left < dis_to_right:
				if dis_to_top > dis_to_down:
					aim_line_angle = 45
				elif dis_to_down > dis_to_top:
					aim_line_angle = 315
				elif dis_to_down == dis_to_top:
					aim_line_angle = 0
			elif dis_to_left == dis_to_right:
				if dis_to_top > dis_to_down:

					aim_line_angle = 90
				elif dis_to_down > dis_to_top:
					aim_line_angle = 270
				elif dis_to_down == dis_to_top:
					aim_line_angle = 135

		d_enemy_x = 0
		d_enemy_y = 0

	if nearest_ang != None:
		re_diction['C'] = new_enemy_x
		re_diction['D'] = new_enemy_y
		if nearest_enemy_last_angle != None:
			d_enemy_x = new_enemy_x - nearest_enemy_last_X
			d_enemy_y = new_enemy_y - nearest_enemy_last_Y
			if nearest_dis > 1000:
				relative_x = relative_x + (d_enemy_x - dx)*(nearest_dis/5)
				relative_y = relative_y + (d_enemy_y - dy)*(nearest_dis/5)
			else:
				relative_x = relative_x + d_enemy_x - dx
				relative_y = relative_y + d_enemy_y - dy
			if relative_x > 0:
				if relative_y > 0:
					aim_line_angle = math.degrees(math.atan(relative_y/relative_x)) 
				elif relative_y < 0:
					aim_line_angle = math.degrees(math.atan(relative_y/relative_x)) +360
				elif relative_y == 0:
					aim_line_angle = 0
			elif relative_x < 0:
				if relative_y > 0:
					aim_line_angle = math.degrees(math.atan(relative_y/relative_x)) +180
				elif relative_y < 0:
					aim_line_angle = math.degrees(math.atan(relative_y/relative_x))+180 
				elif relative_y == 0:
					aim_line_angle = 180
			elif relative_x == 0:
				if relative_y > 0:
					aim_line_angle = 90
				elif relative_y < 0:
					aim_line_angle = 270
				elif relative_y == 0:
					aim_line_angle = 'error' 
		elif nearest_enemy_last_angle == None:
			d_enemy_x = 0
			d_enemy_y = 0

			aim_line_angle = nearest_ang

		

	


				
	
	if state == 'A':
		if 80 < dis_to_left < 85 or 80 < dis_to_right < 85:
			re_diction['ACLT_X'] = 0
		elif dis_to_left >= 85 or dis_to_left <= 80 or dis_to_right >= 85 or dis_to_right <= 80:
			if dis_to_left <= 80:
				re_diction['ACLT_X'] = 1
			elif dis_to_right <= 80:
				re_diction['ACLT_X'] = -1
			elif dis_to_left >= dis_to_right >= 85:
				re_diction['ACLT_X'] = 1
			elif dis_to_right >= dis_to_left >= 85:
				re_diction['ACLT_X'] = -1
		if 110 < dis_to_top < 115 or 110 < dis_to_down < 115:
			re_diction['ACLT_Y'] = 0
		elif dis_to_top >= 115 or dis_to_top <= 110 or dis_to_down >= 115 or dis_to_down <= 110:
			if dis_to_top <= 110:
				re_diction['ACLT_Y'] = 1
			elif dis_to_down <= 110:
				re_diction['ACLT_Y'] = -1
			elif dis_to_top >= dis_to_down >= 115:
				re_diction['ACLT_Y'] = 1
			elif dis_to_down >= dis_to_top >= 115:
				re_diction['ACLT_Y'] = -1
		if dy == 0 and dx == 0:
			re_diction['A'] = 'B'
			re_diction['G'] = False


	if state == 'B':
		if hunt_dir == False and nearest_ang != None:
			if 0 <= nearest_ang <= 45 or 225 < nearest_ang <= 270:
				hunt_dir = 3
			elif 45 < nearest_ang <= 90 or 180 < nearest_ang <= 225:
				hunt_dir = -3
			elif 90 < nearest_ang <= 135 or 315 < nearest_ang <= 360:
				hunt_dir = -4
			elif 135 < nearest_ang <= 180 or 270 < nearest_ang <= 315:
				hunt_dir = 4


		if hunt_dir != False:
			if  hunt_dir == 3:
				re_diction['ACLT_X'] = -1
				re_diction['ACLT_Y'] = -1
			elif hunt_dir == -3:
				re_diction['ACLT_X'] = 1
				re_diction['ACLT_Y'] = 1
			elif hunt_dir == 4:
				re_diction['ACLT_X'] = 1
				re_diction['ACLT_Y'] = -1
			elif hunt_dir == -4:
				re_diction['ACLT_X'] = -1
				re_diction['ACLT_Y'] = 1

		if nearest_ang == None:
				re_diction['ACLT_X'] = 0
				re_diction['ACLT_Y'] = 0
				re_diction['CHARGE'] = True
				re_diction['G'] = False
		
		if (dis_to_left <= 40 and dis_to_left < dis_to_right) or (dis_to_right >= 310 and dis_to_left > dis_to_right):
			re_diction['ACLT_X'] = 1
		if (dis_to_right <= 40 and dis_to_right < dis_to_left) or (dis_to_left >= 310 and dis_to_left < dis_to_right):
			re_diction['ACLT_X'] = -1
		if (dis_to_top <= 40 and dis_to_top < dis_to_down) or (dis_to_down >= 280 and dis_to_top > dis_to_down):
			re_diction['ACLT_Y'] = 1
		if (dis_to_down <= 40 and dis_to_down < dis_to_top) or (dis_to_top >= 280 and dis_to_top < dis_to_down):
			re_diction['ACLT_Y'] = -1
		

				
		if nearest_dis <= 200 and re_diction['ACLT_X'] !=0 and re_diction['ACLT_Y'] !=0:
			if 0 <= nearest_ang <= 45 or 225 < nearest_ang <= 270:
				hunt_dir = 3
			elif 45 < nearest_ang <= 90 or 180 < nearest_ang <= 225:
				hunt_dir = -3
			elif 90 < nearest_ang <= 135 or 315 < nearest_ang <= 360:
				hunt_dir = -4
			elif 135 < nearest_ang <= 180 or 270 < nearest_ang <= 315:
				hunt_dir = 4
		if re_diction['ACLT_X'] == 1:
			if re_diction['ACLT_Y'] == 1:
				re_diction['G'] = -3
			elif re_diction['ACLT_Y'] == -1:
				re_diction['G'] = 4
		if re_diction['ACLT_X'] == -1:
			if re_diction['ACLT_Y'] == -1:
				re_diction['G'] = 3
			elif re_diction['ACLT_Y'] == 1:
				re_diction['G'] = -4
		if nearest_ang != None:
			re_diction['LAUNCH'] = True

		if timer >= 600 and nearest_ang == None:
			re_diction['A'] = 'C'
			re_diction['G'] = False
			

	if state == 'C':
		if hunt_dir == False:
			if 60 <= dis_to_left < dis_to_right:
				re_diction['ACLT_X'] = -1
			elif 60 <= dis_to_right < dis_to_left:
				re_diction['ACLT_X'] = 1
			else:
				re_diction['ACLT_X'] = 0
			if 60 <= dis_to_top < dis_to_down:
				re_diction['ACLT_Y'] = -1
			elif 60 <= dis_to_down < dis_to_top:
				re_diction['ACLT_Y'] = 1
			else:
				re_diction['ACLT_Y'] = 0
			if re_diction['ACLT_X'] == 0 and re_diction['ACLT_Y'] == 0:
				re_diction['G'] = 10

			else:
				re_diction['G'] = False	
		if hunt_dir == 1:
			re_diction['ACLT_X'] = -1
			if nearest_ang == None:
				aim_line_angle = 270
			if dis_to_left <= 60:
				re_diction['ACLT_X'] = 0
				re_diction['ACLT_Y'] = 0
				hunt_dir = 10
		elif hunt_dir == -1:
			re_diction['ACLT_X'] = 1
			if nearest_ang == None:
				aim_line_angle = 90
			if dis_to_right <= 60:
				re_diction['ACLT_X'] = 0
				re_diction['ACLT_Y'] = 0
				hunt_dir = 10
		elif hunt_dir == 2:
			re_diction['ACLT_Y'] = -1
			if nearest_ang == None:
				aim_line_angle = 180
			if dis_to_top <= 60:
				re_diction['ACLT_X'] = 0
				re_diction['ACLT_Y'] = 0
				hunt_dir = 10
		elif hunt_dir == -2:
			re_diction['ACLT_Y'] = 1
			if nearest_ang == None:
				aim_line_angle = 0
			if dis_to_down <= 60:
				re_diction['ACLT_X'] = 0
				re_diction['ACLT_Y'] = 0
				hunt_dir = 10
		if hunt_dir == 10:
			if dis_to_left < dis_to_right:
				if dis_to_top < dis_to_down:
					hunt_dir = -2
				elif dis_to_top > dis_to_down:
					hunt_dir = -1
			elif dis_to_left > dis_to_right:
				if dis_to_top < dis_to_down:
					hunt_dir = 1
				elif dis_to_top > dis_to_down:
					hunt_dir = 2
		if hunt_dir != False:
			re_diction['G'] = hunt_dir
		if nearest_dis < 900 or (nearest_ang != None and (((0 <= nearest_ang <=15 or 345 <= nearest_ang <= 360) and hunt_dir == -1) or (75 <= nearest_ang <= 105 and hunt_dir == 2) or (165 <= nearest_ang <= 195 and hunt_dir == 1) or (265 <= nearest_ang <= 285 and hunt_dir == -2))):
			re_diction['A'] = 'B'
			re_diction['G'] = False


	# The weapon follows the aim line
	if aim_line_angle != None and aim_line_angle != 'error':
		
		if we_angle - aim_line_angle <= -1 or we_angle - aim_line_angle >= 1:
			if -180 <= we_angle - aim_line_angle < 0:
				re_diction['ROT_CC'] = 1
			elif 0 <= we_angle - aim_line_angle <= 180:
				re_diction['ROT_CW'] = 1
			elif we_angle - aim_line_angle < -180:
				re_diction['ROT_CW'] = 1
			elif we_angle - aim_line_angle > 180:
				re_diction['ROT_CC'] = 1
		else:
			if we_angle - aim_line_angle >= 0:
				re_diction['ROT_CW'] = (we_angle - aim_line_angle)/2

			elif we_angle - aim_line_angle < 0:
				re_diction['ROT_CC'] = (aim_line_angle - we_angle)/2
		



	# if target is near by the tank, combat with it
	if nearest_ang != None :
		re_diction['LAUNCH'] = True
	
	if not -1.5 < aim_line_angle - we_angle < 1.5:
		re_diction['LAUNCH'] = False
		
	if nearest_dis <= 200:
		re_diction['CHARGE'] = False
	
	if nearest_ang != None and (0 <= nearest_ang <=15 or 75 <= nearest_ang <= 105 or 165 <= nearest_ang <= 195 or 265 <= nearest_ang <= 285 or 345 <= nearest_ang <= 360 ) or (-4 <= ((d_enemy_x-dx)**2 + (d_enemy_y-dy)**2)**0.5 <= 4):

		if H_R_timer == 0:
			re_diction['I'] = timer
			re_diction['CHARGE'] = True
			re_diction['SHIELD'] = True
		elif state_charge and timer-H_R_timer >= Hit_delay :
			re_diction['CHARGE'] = False
			re_diction['SHIELD'] = False
			re_diction['I'] = -1*timer
		elif not state_charge and timer+ H_R_timer >= Run_delay :
			re_diction['CHARGE'] = True
			re_diction['SHIELD'] = True
			re_diction['I'] = timer

	if nearest_ang == None and (nearest_enemy_last_angle != None or state == 'B'):
		H_R_timer = 0
		re_diction['CHARGE'] = True
		re_diction['SHIELD'] = True
	if nearest_ang == None and ((H_R_timer >= 0 and timer-H_R_timer >= H_R_delay + 2) or (H_R_timer <= 0 and timer+ H_R_timer >= H_R_delay + 2)):
		if we_power >= 100:
			re_diction['CHARGE'] = False
			re_diction['SHIELD'] = False


	if nearest_ang != None:
		x1 = x + (math.cos(math.radians(nearest_ang)) * 200)
		y1 = y - (math.sin(math.radians(nearest_ang)) * 200)
		re_diction['D_LINE']=  ((x, y) , (x1, y1))

	#re_diction['CHARGE'] = False
	#re_diction['LAUNCH'] = False
	#re_diction['SHIELD'] = False
	'''
	# After taken damage, activate the shield for 1 second
	if timer - last_time_been_attacked >= 20 and state_shield:
		state_shield = False
		re_diction['SHIELD'] = False


	if taken_damage - had_taken_damage > 0 and not state_shield:
		state_shield = True
		re_diction['SHIELD'] = True
		re_diction['E'] = taken_damage

		re_diction['F'] = timer
	'''
	if we_power <=1:
		if  state_charge:
			re_diction['LAUNCH'] = False



	return('chioce',re_diction)

	
		
			

